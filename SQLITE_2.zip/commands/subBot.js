const { Client } = require('discord.js-selfbot-v13');
const { joinVoiceChannel } = require('@discordjs/voice');

const token = process.argv[2];
const channelId = process.argv[3];

const client = new Client();
let connection = null;

client.once('ready', async () => {
  console.log(`Bot with token ${token} is ready!`);
  
  client.user.setStatus("idle");

  try {
    const channel = await client.channels.fetch(channelId);
    
    // Join the voice channel
    await joinChannel(channel);
  } catch (error) {
    console.error(`Error fetching the channel: ${error}`);
  }
});

async function joinChannel(channel) {
  try {
    connection = joinVoiceChannel({
      channelId: channel.id,
      guildId: channel.guild.id,
      adapterCreator: channel.guild.voiceAdapterCreator,
      selfMute: true,
      selfDeaf: true,
    });

    console.log(`Joined the voice channel: ${channelId}`);

    // Connection event listeners
    connection.on('stateChange', (oldState, newState) => {
      console.log(`Connection state changed: ${newState.status}`);
      if (newState.status === 'Disconnected') {
        console.log(`Disconnected from voice channel. Attempting to reconnect in 5 seconds...`);
        setTimeout(() => {
          joinChannel(channel); // Attempt to reconnect
        }, 5000);
      }
    });

    connection.on('error', (error) => {
      console.error(`Voice connection error: ${error}`);
    });

    connection.on('disconnect', (disconnectReason) => {
      console.log(`Disconnected from voice channel: ${disconnectReason}`);
    });
  } catch (error) {
    console.error(`Error joining the voice channel: ${error}`);
  }
}

// Log in the bot
client.login(token);
