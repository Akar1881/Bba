const { REST, Routes, SlashCommandBuilder } = require('discord.js');
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

// Load configuration
const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../config.json')));

// Initialize SQLite database
const db = new sqlite3.Database('./data/data.sqlite');

// Register slash commands
const commands = [
  new SlashCommandBuilder()
    .setName('add_token')
    .setDescription('Add token and voice channel ID')
    .addStringOption(option => option.setName('token').setDescription('The bot token').setRequired(true))
    .addStringOption(option => option.setName('idvoice').setDescription('The voice channel ID').setRequired(true))
    .toJSON(),
  
  new SlashCommandBuilder()
    .setName('remove_token')
    .setDescription('Remove token and stop bot instance')
    .addStringOption(option => option.setName('token').setDescription('The bot token to remove').setRequired(true))
    .toJSON(),
  
  new SlashCommandBuilder()
    .setName('token_list')
    .setDescription('Send the list of tokens in private chat')
    .toJSON(),
  
  new SlashCommandBuilder()
    .setName('limit')
    .setDescription('Manage token limits for users')
    .addStringOption(option => option.setName('action').setDescription('Action to perform (remove/give)').setRequired(true)
      .addChoices(
        { name: 'remove', value: 'remove' },
        { name: 'give', value: 'give' }
      ))
    .addUserOption(option => option.setName('user').setDescription('The user to modify').setRequired(true))
    .addIntegerOption(option => option.setName('amount').setDescription('The amount to add/remove').setRequired(true))
    .toJSON(),
  
  new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Claim your daily coins.')
    .toJSON(),
  
  new SlashCommandBuilder()
    .setName('credit')
    .setDescription('Check your current coin balance.')
    .toJSON(),
  
  new SlashCommandBuilder()
    .setName('buy_limit')
    .setDescription('Buy additional token limit.')
    .addIntegerOption(option => option.setName('amount').setDescription('Amount of additional tokens to buy.').setRequired(true))
    .toJSON(),
    
  new SlashCommandBuilder()
    .setName('reconnect')
    .setDescription('To reconnect all accounts')
    .toJSON(),
  
  new SlashCommandBuilder()
    .setName('help')
    .setDescription('To see all commands')
    .toJSON(),
];

const registerCommands = async () => {
  const rest = new REST({ version: '10' }).setToken(config.token);
  
  try {
    console.log('Started refreshing application (/) commands.');
    await rest.put(Routes.applicationCommands(config.clientId), { body: commands });
    console.log('Successfully reloaded application (/) commands.');
  } catch (error) {
    console.error(error);
  }
};

// Command interaction handling
const handleInteraction = async (interaction, client) => {
  if (!interaction.isCommand()) return;

  const { commandName, options, user } = interaction;

  switch (commandName) {
    case 'add_token':
      const token = options.getString('token');
      const channelId = options.getString('idvoice');

      db.get(`SELECT tokens_limit FROM limits WHERE userId = ?`, [user.id], async (err, row) => {
        if (err) {
          console.error(err);
          return await interaction.reply({ content: 'Database error.', ephemeral: true });
        }
        
        const userLimit = row ? row.tokens_limit : 1;

        db.all(`SELECT * FROM config WHERE userId = ?`, [user.id], async (err, tokens) => {
          if (err) {
            console.error(err);
            return await interaction.reply({ content: 'Database error.', ephemeral: true });
          }

          if (tokens.length >= userLimit) {
            return await interaction.reply({ content: `You have reached your token limit of ${userLimit}.`, ephemeral: true });
          }

          db.run(`INSERT INTO config (token, channelId, userId) VALUES (?, ?, ?)`, [token, channelId, user.id], async (err) => {
            if (err) {
              console.error(err.message);
              return await interaction.reply({ content: 'Error saving token.', ephemeral: true });
            }
            
            await interaction.reply({ content: 'Token saved.', ephemeral: true });
          });
        });
      });
      break;

    case 'remove_token':
      const tokenToRemove = options.getString('token');

      db.get(`SELECT * FROM config WHERE token = ? AND userId = ?`, [tokenToRemove, user.id], async (err, row) => {
        if (err) {
          console.error(err);
          return await interaction.reply({ content: 'Database error.', ephemeral: true });
        }

        if (!row) {
          return await interaction.reply({ content: 'Token not found or you do not have permission to remove it.', ephemeral: true });
        }

        db.run(`DELETE FROM config WHERE token = ?`, [tokenToRemove], async (err) => {
          if (err) {
            console.error(err.message);
            return await interaction.reply({ content: 'Error removing token.', ephemeral: true });
          }
          await interaction.reply({ content: `Token ${tokenToRemove} has been removed.`, ephemeral: true });
        });
      });
      break;

    case 'token_list':
      db.all(`SELECT token FROM config WHERE userId = ?`, [user.id], async (err, rows) => {
        if (err) {
          console.error(err);
          return await interaction.reply({ content: 'Database error.', ephemeral: true });
        }

        const userTokens = rows.map(row => row.token).join('\n') || 'No tokens available.';
        try {
          await user.send(`Here is the list of your tokens:\n${userTokens}`);
          await interaction.reply({ content: 'Token list has been sent to your DMs.', ephemeral: true });
        } catch (error) {
          console.error(`Could not send DM to ${user.tag}.\n`, error);
          await interaction.reply({ content: 'I could not send you a DM. Please check your privacy settings.', ephemeral: true });
        }
      });
      break;
      
      case 'reconnect':
  if (!config.ownerIDs.includes(user.id)) {
    await interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
    return;
  }

  // Load existing bot instances from database
  db.query(`SELECT * FROM config`, (err, rows) => {
    if (err) {
      console.error('Database error:', err);
      return;
    }

    rows.forEach(({ token, channelId }) => {
      const subBotProcess = spawn('node', [path.join(__dirname, 'subBot.js'), token, channelId]);

      subBotProcess.stdout.on('data', (data) => {
        console.log(`Account restarted successfully for token: ${token}`);
      });

      subBotProcess.stderr.on('data', (data) => {
        console.error(`Error in subBot process for token ${token}: ${data}`);
      });

      subBotProcess.on('close', (code) => {
        console.log(`SubBot process for token ${token} exited with code: ${code}`);
      });
    });
  });

  // Send response to interaction
  await interaction.reply({ content: 'All accounts have been restarted. Please wait 5 seconds.', ephemeral: true });
  break;

    case 'limit':
      if (!config.ownerIDs.includes(user.id)) {
        await interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
        return;
      }

      const action = options.getString('action');
      const targetUser = options.getUser('user');
      const amount = options.getInteger('amount');

      if (action === 'give') {
        db.run(`INSERT OR REPLACE INTO limits (userId, tokens_limit) VALUES (?, ?)`, [targetUser.id, (limits.users[targetUser.id]?.tokens_limit || 1) + amount]);
        await interaction.reply({ content: `User ${targetUser.tag}'s token limit has been increased by ${amount}.`, ephemeral: true });
      } else if (action === 'remove') {
        db.run(`INSERT OR REPLACE INTO limits (userId, tokens_limit) VALUES (?, ?)`, [targetUser.id, Math.max(1, (limits.users[targetUser.id]?.tokens_limit || 1) - amount)]);
        await interaction.reply({ content: `User ${targetUser.tag}'s token limit has been decreased by ${amount}.`, ephemeral: true });
      }
      break;

    case 'daily':
      db.get(`SELECT coins, lastClaim FROM balance WHERE userId = ?`, [user.id], async (err, row) => {
        if (err) {
          console.error(err);
          return await interaction.reply({ content: 'Database error.', ephemeral: true });
        }
        
        const now = Date.now();
        const lastClaim = row ? row.lastClaim : 0;
        const hoursSinceLastClaim = (now - lastClaim) / (1000 * 60 * 60);
        
        if (hoursSinceLastClaim < 24) {
          const remainingHours = 24 - hoursSinceLastClaim;
          await interaction.reply(`You can claim your daily coins in ${remainingHours.toFixed(1)} hours.`);
        } else {
          const dailyCoins = 3;
          const newCoins = (row ? row.coins : 0) + dailyCoins;

          db.run(`INSERT OR REPLACE INTO balance (userId, coins, lastClaim) VALUES (?, ?, ?)`, [user.id, newCoins, now]);
          await interaction.reply(`You have claimed your daily ${dailyCoins} coins. Total coins: ${newCoins}`);
        }
      });
      break;

    case 'credit':
      db.get(`SELECT coins FROM balance WHERE userId = ?`, [user.id], async (err, row) => {
        if (err) {
          console.error(err);
          return await interaction.reply({ content: 'Database error.', ephemeral: true });
        }

        const userBalance = row ? row.coins : 0;
        db.get(`SELECT tokens_limit FROM limits WHERE userId = ?`, [user.id], async (err, limitRow) => {
          if (err) {
            console.error(err);
            return await interaction.reply({ content: 'Database error.', ephemeral: true });
          }

          const userLimit = limitRow ? limitRow.tokens_limit : 1;
          await interaction.reply(`You have ${userBalance} coins and a token limit of ${userLimit}.`);
        });
      });
      break;

    case 'buy_limit':
      const amountToBuy = options.getInteger('amount');
      const cost = amountToBuy * 20;

      db.get(`SELECT coins FROM balance WHERE userId = ?`, [user.id], async (err, row) => {
        if (err) {
          console.error(err);
          return await interaction.reply({ content: 'Database error.', ephemeral: true });
        }

        const userBalance = row ? row.coins : 0;

        if (userBalance < cost) {
          await interaction.reply(`You do not have enough coins. This purchase requires ${cost} coins.`);
          return;
        }

        const newBalance = userBalance - cost;
        db.run(`INSERT OR REPLACE INTO balance (userId, coins) VALUES (?, ?)`, [user.id, newBalance]);
        db.run(`INSERT OR REPLACE INTO limits (userId, tokens_limit) VALUES (?, ?)`, [user.id, (limits.users[user.id]?.tokens_limit || 1) + amountToBuy]);

        await interaction.reply(`You have bought ${amountToBuy} additional token limit for ${cost} coins.`);
      });
      break;

    case 'help':
      const helpMessage = `
        **All My Commands**
        /add_token: Add an account to stream in voice.
        /remove_token: Remove an account from streaming.
        /token_list: See the list of tokens you added.
        /daily: Claim your daily coins.
        /credit: See your coins and tokens.
        /buy_limit: Buy more tokens for streaming using coins.
      `;
      await interaction.reply(helpMessage);
      break;

    default:
      await interaction.reply({ content: 'Unknown command.', ephemeral: true });
      break;
  }
};

module.exports = { registerCommands, handleInteraction };
