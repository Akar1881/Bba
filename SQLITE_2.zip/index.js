const { Client, GatewayIntentBits } = require('discord.js');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();
const { registerCommands, handleInteraction } = require('./commands/commands');
const { spawn } = require('child_process');
const path = require('path');
const config = JSON.parse(fs.readFileSync('./config.json'));

// Initialize SQLite database
const db = new sqlite3.Database('./data/data.sqlite');

// Create necessary tables
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS config (token TEXT PRIMARY KEY, channelId TEXT, userId TEXT)`);
  db.run(`CREATE TABLE IF NOT EXISTS limits (userId TEXT PRIMARY KEY, tokens_limit INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS balance (userId TEXT PRIMARY KEY, coins INTEGER, lastClaim INTEGER)`);
});

// Client initialization
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers] });

client.once('ready', () => {
  console.log('Main bot is ready!');
  registerCommands(); // Register commands

  // Load existing bot instances
  db.all(`SELECT * FROM config`, [], (err, rows) => {
    if (err) {
      console.error(err);
      return;
    }

    rows.forEach(({ token, channelId }) => {
      // Spawn a new sub-bot process for each token and channelId
      const subBotProcess = spawn('node', [path.join(__dirname, 'subBot.js'), token, channelId]);

      // Handle sub-bot process events
      subBotProcess.stdout.on('data', (data) => {
        console.log(`Sub-bot output: ${data}`);
      });

      subBotProcess.stderr.on('data', (data) => {
        console.error(`Sub-bot error: ${data}`);
      });

      subBotProcess.on('close', (code) => {
        console.log(`Sub-bot process exited with code ${code}`);
      });
    });
  });
});

client.on('interactionCreate', (interaction) => {
  handleInteraction(interaction, client); // Handle interactions
});

// Log in the bot
client.login(config.token);
